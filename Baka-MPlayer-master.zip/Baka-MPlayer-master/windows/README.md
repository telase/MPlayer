﻿# README

## Native Windows Compilation
For native windows compilation see: https://github.com/amazingfate/baka-build/ or https://github.com/u8sand/baka-build. When a more standard way is made to do this it will be placed here.

## Cross Windows Compilation
For cross-compilation for windows on linux see the `cross-compilation/` directory for related scripts.
