#include "util.h"

namespace Util {

QString DownloadFileUrl()
{
    return "http://bakamplayer.u8sand.net/Baka.MPlayer.64-bit.zip";
}

}
