#include "util.h"

namespace Util {

QString DownloadFileUrl()
{
    return "http://bakamplayer.u8sand.net/Baka.MPlayer.32-bit.zip";
}

}
